# Sailing Price Watch – run kit

Scripts used by the daily "Sailing price watch" scheduled task for the Ambassador Cruise Line ad feed.

- `enrich.py TODAY` – fetch the Google ad feed + landing pages, write `data/snapshot_TODAY.json`
- `tracker.py STATE SNAPSHOT OUT CABINS` – fold today's prices into the tracker state, write `out/state.json`, `out/cabins.json`, `out/run.json`
- `render_cards.py SNAPSHOT OUTDIR ID [--cabin TYPE] [--was PRICE]` – render 1x1, 3x4 and 9x16 ad cards

State lives in the Sailing Price Watch tracker artifact's database, not in this repo.
Generated folders (data/, out/, cards/, db/, img_cache/) are git-ignored.
